MeetingCost - Watch this meeting cost you money, live
=====================================================

Quick start (60 seconds)

1. Double-click MeetingCost.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Per meeting, per month, per year — shock included
- Live meter that ticks up as the meeting runs
- Cancel-it checklist and a Slack-ready summary

Why this tool

The one-dollar counter nobody can argue with, offline and screen-shottable

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
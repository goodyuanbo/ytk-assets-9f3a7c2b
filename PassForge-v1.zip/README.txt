PassForge - Offline password generator and strength audit
=========================================================

Quick start (60 seconds)

1. Double-click PassForge.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Works in airplane mode — zero network requests, ever
- Random passwords (8-64) and passphrases from 2,351 offline words
- Audits against 1,700+ breached passwords, keyboard walks and sequences
- Entropy in bits plus crack-time estimate on a stated assumption
- Batch-audit a list of candidates in one pass

Why this tool

Online password generators are a privacy paradox — this one never sees your secret

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
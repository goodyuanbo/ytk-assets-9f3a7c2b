PrivacyForge - Privacy policy + cookie consent banner, generated offline
========================================================================

Quick start (60 seconds)

1. Double-click PrivacyForge.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Full privacy policy with GDPR legal bases, retention and user rights
- CCPA/CPRA section with Do Not Sell / Global Privacy Control
- Ready-to-paste cookie banner: blocks scripts until consent
- Export policy.md, policy.html and consent-banner.html
- Compliance checklist flags what is still missing

Why this tool

A one-time alternative to Termly and Iubenda — no monthly fee, nothing sent to a server

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
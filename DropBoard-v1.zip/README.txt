DropBoard — CSV to Dashboard
=============================

Quick start (60 seconds)

1. Double-click DropBoard.html — it opens in your browser.
2. Click "Load sample" to see it working with demo data.
3. Drag your own .csv file onto the page. Done.

Tips
----
- Works completely offline. Your file never leaves your computer.
- Supports comma / semicolon / tab separated files, $ amounts, % values,
  parenthesized negatives, and common date formats.
- Click any column header in the table to sort.
- Use the Export buttons for PNG (all charts), standalone HTML
  (your dashboard with data baked in — share it with anyone),
  or filtered CSV.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.

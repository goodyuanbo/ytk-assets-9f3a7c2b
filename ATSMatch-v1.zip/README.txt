ATSMatch - See your resume the way the filter does
==================================================

Quick start (60 seconds)

1. Double-click ATSMatch.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Keyword coverage against the real job description
- Format risks that break parsing, plus quantified-impact checks
- Prioritised fix list, exportable as Markdown

Why this tool

One-time $15 instead of Jobscan at $50 a month, and your resume never touches a server

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
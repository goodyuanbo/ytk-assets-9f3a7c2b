ReqForge - cURL to code, and back. Locally.
===========================================

Quick start (60 seconds)

1. Double-click ReqForge.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- cURL to fetch / axios / requests / Go / PHP in one click
- Reverse: paste Python or JS, get cURL back
- One-click secret redaction before you paste anywhere else

Why this tool

Your Authorization headers never leave the machine, and it converts backwards too

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
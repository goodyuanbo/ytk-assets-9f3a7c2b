PixelPress - Batch image resizer & compressor
=============================================

Quick start (60 seconds)

1. Double-click PixelPress.html.
2. Drop in as many images as you like (JPG / PNG / WebP / GIF / BMP).
3. Set max width/height, output format and quality, then 'Process all'.
4. Download one file, all files, or a single ZIP.

Tips
----
- Everything runs in your browser via canvas - images never leave your machine.
- Resize keeps the aspect ratio. Set one side to 0 to ignore it.
- Quality only affects JPEG/WebP; PNG output is always lossless.
- The % badge on each card shows how much smaller the file got.
- ZIP is built locally (stored entries) - no server, no upload, no limits.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
RunwayCalc - See the exact month your cash hits zero
====================================================

Quick start (60 seconds)

1. Double-click RunwayCalc.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Month-by-month cash flow with one-off costs and inflows
- Optimistic / base / pessimistic runway side by side
- Break-even revenue and the cut needed for 18 months

Why this tool

Your burn rate is nobody else business — it runs offline with no login and no subscription

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
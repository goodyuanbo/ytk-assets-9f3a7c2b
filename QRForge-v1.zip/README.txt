QRForge - Batch QR codes you actually own
=========================================

Quick start (60 seconds)

1. Double-click QRForge.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- WiFi, vCard, URL, plain text
- Colors, dot style, center logo
- Bulk generate from a list

Why this tool

Generates locally, no monthly QR subscription

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
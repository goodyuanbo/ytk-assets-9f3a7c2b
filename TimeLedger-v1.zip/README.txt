TimeLedger - Time tracker with billing
======================================

Quick start (60 seconds)

1. Double-click TimeLedger.html.
2. Add a project (name + hourly rate + currency).
3. Pick it, type what you are doing, hit Start. Hit Stop to save the entry.
4. Filter and export CSV invoice lines when it is time to bill.

Tips
----
- Data lives in your browser's local storage - private and instant.
- Manual entries supported: type hours directly for work you forgot to track.
- Billable / billed checkboxes per entry, so you always know what is unpaid.
- KPIs: tracked hours, billable value, unbilled total, this week, per project.
- CSV export groups entries by project into ready-made invoice lines.
- JSON backup / restore so you can move between machines.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
RAGSplit - See your chunks before you ship them
===============================================

Quick start (60 seconds)

1. Double-click RAGSplit.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- 4 strategies (fixed / paragraph / sentence / Markdown heading)
- Overlap visually highlighted in every chunk
- Live cost estimate across 3 embedding tiers

Why this tool

Tune chunking on real text, not in code

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
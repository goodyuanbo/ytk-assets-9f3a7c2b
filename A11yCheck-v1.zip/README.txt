A11yCheck - WCAG contrast checker with live preview and auto-fix
================================================================

Quick start (60 seconds)

1. Double-click A11yCheck.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Instant AA / AAA pass-fail for normal and large text
- Real preview: headings, body, buttons and links in your colours
- Auto-suggests the nearest passing hex, lighten or darken
- Colour-blind simulation: protanopia, deuteranopia, tritanopia
- Whole-palette contrast matrix from a pasted list

Why this tool

It shows you the fix, not just the ratio — built for the EU Accessibility Act deadline

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
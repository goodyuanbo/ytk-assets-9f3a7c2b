LateFee - Chase invoices without losing your temper
===================================================

Quick start (60 seconds)

1. Double-click LateFee.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Interest, fixed fees and the total owed today
- Five-email sequence, calm and non-threatening
- Fill-in placeholders ready to send

Why this tool

Writes the awkward email for you, locally, with none of your client data leaving the tab

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
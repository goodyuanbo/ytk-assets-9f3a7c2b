ThumbForge - Big-text thumbnails in 30 seconds
==============================================

Quick start (60 seconds)

1. Double-click ThumbForge.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Auto-scaling headline text that always fills the frame
- Gradient, solid or image backgrounds with blur and darken
- Arrows, highlight shapes, bottom bars and corner badges
- Export 1280x720, 1080x1080 or 1080x1920 PNG
- Last 5 designs saved locally so you can revisit them

Why this tool

Built only for thumbnails, not a general designer

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
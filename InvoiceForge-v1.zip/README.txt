InvoiceForge - Invoice & quote generator
========================================

Quick start (60 seconds)

1. Double-click InvoiceForge.html - it opens in your browser.
2. Fill in your details once, then click 'Save draft' - they are remembered
   on this computer.
3. Add line items. The preview on the right updates as you type.
4. Click 'Print / Save PDF' and choose 'Save as PDF' to get a clean,
   print-ready A4 invoice.

Tips
----
- Works 100% offline. Nothing is uploaded - not your client list, not your rates.
- Automatic maths: discount %, tax %, amount paid and balance due.
- Switch between Invoice / Quote / Receipt with one dropdown.
- Save clients with the 'Save client' button, then pick them from the dropdown.
- 9 currencies built in ($ EUR GBP YEN INR AUD CAD CHF kr).
- Export JSON (re-import later) or CSV of line items for bookkeeping.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
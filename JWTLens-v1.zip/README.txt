JWTLens - Decode tokens without leaking them
============================================

Quick start (60 seconds)

1. Double-click JWTLens.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Payload decoded locally, never uploaded
- 7-point security check
- HS256 signature verify with your key

Why this tool

Security audit, not just a decoder

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
CronWhisper - See what your cron actually means
===============================================

Quick start (60 seconds)

1. Double-click CronWhisper.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Bidirectional visual editor
- Next 5 run times in your timezone
- Plain-English translation

Why this tool

Two-way editing, not just another translator

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
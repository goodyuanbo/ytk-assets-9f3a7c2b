BioLink - Export a self-contained link-in-bio page
==================================================

Quick start (60 seconds)

1. Double-click BioLink.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Exports one single HTML file with every style and image inlined
- Six themes, avatar upload, unlimited links with icons and highlights
- Optional YouTube embed, subscribe box and social icon row
- Live 375px phone preview while you type
- Host it anywhere: GitHub Pages, Netlify, your own server

Why this tool

No watermark, no account, no $9/month - you own the file

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
SRTStudio - Fix subtitle timing offline
=======================================

Quick start (60 seconds)

1. Double-click SRTStudio.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Open .srt and .vtt, edit every cue in a plain table
- Shift, scale and re-time the whole file or just the second half
- Batch clean text: strip tags, wrap long lines, find and replace
- Flags overlaps, unreadable short cues and over-long lines
- Export .srt, .vtt or plain transcript, full UTF-8 and CJK support

Why this tool

Subtitle timing fixes without installing Subtitle Edit or uploading to a site

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
ChapterForge - Podcast and video chapters, cleaned up
=====================================================

Quick start (60 seconds)

1. Double-click ChapterForge.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Pastes in messy "time - title" lists and normalises them
- YouTube, podcast:chapter JSON, ID3 CHAP, Markdown or plain text
- Checks first chapter is 00:00, 3+ chapters and 10s minimum
- Shows each chapter's share of the episode as a bar chart
- One-click copy straight into the YouTube description box

Why this tool

The messy-timestamp cleaner is the whole point, not a side feature

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
TaxNap - Know your quarterly tax before it knows you
====================================================

Quick start (60 seconds)

1. Double-click TaxNap.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- 2025 brackets, self-employment tax, state estimate
- Four quarterly payment amounts
- How much to set aside per payment

Why this tool

Local-only, no account, one-time $19 instead of $50/year

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
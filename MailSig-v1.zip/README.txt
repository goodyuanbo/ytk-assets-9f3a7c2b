MailSig - Email signature builder with real rich-text copy
==========================================================

Quick start (60 seconds)

1. Double-click MailSig.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Ten genuinely different layouts: dark card, CTA, QR slot, minimal and more
- True rich-text copy that pastes into Gmail and Outlook with formatting
- Avatar upload or generated initials, inline SVG social icons
- Custom brand colour and system-safe font stack
- Mobile-width preview plus shrinking advice that actually helps

Why this tool

One click copies formatted HTML, not a wall of source code

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
Page2CSV — grab any web table as a clean CSV
=============================================

Quick start (30 seconds)

1. Open Page2CSV.html in your browser.
2. Drag the orange "Page2CSV" button onto your bookmarks bar.
   (Bookmarks bar hidden? Press Ctrl+Shift+B on Windows, Cmd+Shift+B on Mac.)
3. Visit any page with a table. Click the Page2CSV bookmark.
4. Pick the table from the popup. It downloads as CSV. Done.

No bookmark handy?
------------------
View the page source (Ctrl+U), copy the HTML, and paste it into the
"Or paste HTML here" box in Page2CSV.html. Same result.

What gets cleaned automatically
-------------------------------
- Merged cells (colspan / rowspan) expanded — every row has all columns
- Hidden elements and script leftovers stripped
- Tabs, non-breaking spaces and doubled spaces collapsed
- Header rows that repeat mid-table removed
- Commas, quotes and newlines inside cells quoted correctly
- UTF-8 BOM added so Excel opens it right on double-click

Requirements: any modern browser. Nothing to install, nothing leaves your machine.

Pair it with DropBoard (same shop) to turn the CSV into charts in one drop.

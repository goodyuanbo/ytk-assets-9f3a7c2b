AIDisclose - AI-use disclosure statements that hold up
======================================================

Quick start (60 seconds)

1. Double-click AIDisclose.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- 8 scenarios from coursework to client delivery
- Three lengths: one line, one paragraph, full appendix
- APA 7 and IEEE reference lines generated automatically
- Per-scenario risk notes and prompt-log reminders
- Export .md / .txt, copy in one click

Why this tool

It generates the disclosure you actually need — not another AI detector

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
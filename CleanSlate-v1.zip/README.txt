CleanSlate - Text cleanup toolbox
=================================

Quick start (60 seconds)

1. Double-click CleanSlate.html.
2. Paste messy text into the box ('Load sample' shows you what it can do).
3. Click the operation you want. Chain as many as you like.
4. Undo goes back one step. Copy or download when you are happy.

Tips
----
- 30+ one-click operations: trim, de-duplicate, sort, case, wrap, number lines...
- Find & replace supports real regular expressions with custom flags.
- Extract emails, URLs or numbers out of any wall of text.
- Base64 / URL encode-decode, JSON pretty-print and minify.
- Diff tab shows added / removed lines between two versions of a text.
- Everything is local - paste confidential data with no risk.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
MarkForge - Markdown to beautiful HTML
======================================

Quick start (60 seconds)

1. Double-click MarkForge.html.
2. Type or paste Markdown on the left - the right side renders live.
3. Pick a document style: Clean, Dark or Editorial.
4. 'Export HTML' gives you one self-contained file you can host anywhere.

Tips
----
- Supports headings, bold/italic/strike, code blocks, tables, task lists,
- blockquotes, nested lists, links, images and horizontal rules.
- Exported HTML has the CSS embedded - a single file, no assets, no CDN.
- Also exports raw .md, copies HTML to clipboard, and prints to PDF.
- Live word count and reading time.
- No build step, no npm, no internet needed.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
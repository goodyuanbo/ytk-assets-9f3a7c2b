SubLens - See what your subscriptions actually cost you
=======================================================

Quick start (60 seconds)

1. Double-click SubLens.html - it opens in your browser.
2. That is it. There is no step 2: no install, no account, no internet needed.
3. Every feature is one click away in the page header and panels.
4. Your work is saved locally in the browser and can be exported anytime.

What you get

- Monthly, annual and 3-year cost for every subscription
- Zombie waste: what you pay for things you no longer use
- Sorted annual-cost bars and per-category breakdown
- 60-day renewal calendar with a 7-day cancel window
- CSV and JSON export, local-only storage

Why this tool

Turns an invisible monthly drip into one number you cannot unsee

Privacy

- Everything runs in your browser. Nothing is uploaded. No analytics, no
  account, no tracking. You can use it on a plane.
- Uninstall = delete the file. That is the whole uninstall process.

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.
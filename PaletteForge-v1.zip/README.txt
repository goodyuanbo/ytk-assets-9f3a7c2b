PaletteForge - Color palette from any image
===========================================

Quick start (60 seconds)

1. Double-click PaletteForge.html.
2. Drop a logo, screenshot or photo (or 'Use sample image').
3. Drag the slider to pick how many colors (3-12).
4. Click any swatch to test contrast, then export the palette.

Tips
----
- Colors are extracted by frequency with a distance filter, so you get
- distinct colors instead of ten shades of the same grey.
- Each swatch shows HEX, RGB, HSL, share %, plus tint and shade ramps.
- WCAG 2.1 contrast checker with live AA / AAA / UI verdicts.
- Export to CSS variables, Tailwind config, SCSS, JSON, SVG or .gpl
- (GIMP / Photoshop palette file).

Requirements: any modern browser (Chrome, Edge, Firefox, Safari). Nothing else.

Questions: reply to your Gumroad download email.